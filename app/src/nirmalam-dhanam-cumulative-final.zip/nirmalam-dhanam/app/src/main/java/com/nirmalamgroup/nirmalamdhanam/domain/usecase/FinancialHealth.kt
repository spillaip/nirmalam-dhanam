package com.nirmalamgroup.nirmalamdhanam.domain.usecase

import com.nirmalamgroup.nirmalamdhanam.data.local.AccountBalance
import com.nirmalamgroup.nirmalamdhanam.data.local.AccountKind
import com.nirmalamgroup.nirmalamdhanam.data.local.AccountEntity
import com.nirmalamgroup.nirmalamdhanam.data.local.InvestmentBalanceSnapshotEntity
import com.nirmalamgroup.nirmalamdhanam.data.local.TransactionDirection
import com.nirmalamgroup.nirmalamdhanam.data.local.TransactionEntity
import kotlin.math.roundToInt

data class HealthComponent(val name: String, val score: Int, val explanation: String)
data class FinancialHealth(val overallScore: Int, val components: List<HealthComponent>)

object FinancialHealthCalculator {
    fun calculate(
        accounts: List<AccountEntity>,
        balances: List<AccountBalance>,
        transactions: List<TransactionEntity>,
        latestInvestments: List<InvestmentBalanceSnapshotEntity>
    ): FinancialHealth {
        val ninetyDaysAgo = System.currentTimeMillis() - 90L * 24 * 60 * 60 * 1000
        val confirmed = transactions.filter { !it.isHoldingTank && it.occurredAtEpochMs >= ninetyDaysAgo }
        val income = confirmed.filter { it.direction == TransactionDirection.CREDIT }.sumOf { it.amountPaise }
        val expense = confirmed.filter { it.direction == TransactionDirection.DEBIT && it.envelopeType != com.nirmalamgroup.nirmalamdhanam.data.local.EnvelopeType.INVESTMENT }.sumOf { it.amountPaise }
        val savingsRate = if (income <= 0) 0.0 else ((income - expense).coerceAtLeast(0) * 100.0 / income)
        val cashFlow = savingsRate.coerceIn(0.0, 35.0) / 35.0 * 100.0

        val reserves = balances.filter { it.kind == AccountKind.EMERGENCY || it.kind == AccountKind.SAVINGS }.sumOf { it.balancePaise.coerceAtLeast(0) }
        val spending = balances.filter { it.kind == AccountKind.SPENDING }.sumOf { it.balancePaise.coerceAtLeast(0) }
        val monthlyBurn = (expense / 3.0).coerceAtLeast(1.0)
        val reserveMonths = (reserves + spending) / monthlyBurn
        val reserveScore = (reserveMonths / 6.0 * 100.0).coerceIn(0.0, 100.0)

        val targetable = accounts.filter { it.kind == AccountKind.INVESTMENT && it.targetAllocationBps > 0 }
        val values = latestInvestments.associate { it.accountId to it.currentValuePaise }
        val totalPortfolio = targetable.sumOf { values[it.id] ?: 0L }
        val driftScore = if (targetable.isEmpty() || totalPortfolio <= 0) 50.0 else {
            val absoluteDrift = targetable.sumOf { account ->
                val currentBps = ((values[account.id] ?: 0L) * 10_000.0 / totalPortfolio)
                kotlin.math.abs(currentBps - account.targetAllocationBps)
            } / 2.0
            (100.0 - absoluteDrift / 100.0).coerceIn(0.0, 100.0)
        }

        val debt = balances.filter { it.kind == AccountKind.CREDIT }.sumOf { (-it.balancePaise).coerceAtLeast(0) }
        val liquid = balances.filter { it.kind != AccountKind.INVESTMENT }.sumOf { it.balancePaise.coerceAtLeast(0) }
        val solvency = if (debt == 0L) 100.0 else (liquid * 100.0 / (liquid + debt)).coerceIn(0.0, 100.0)

        val components = listOf(
            HealthComponent("Cash flow", cashFlow.roundToInt(), "Based on confirmed income versus expenses."),
            HealthComponent("Emergency reserve", reserveScore.roundToInt(), "Based on liquid reserves versus observed spending burn."),
            HealthComponent("Portfolio alignment", driftScore.roundToInt(), "Based on current investment weights versus your own targets."),
            HealthComponent("Solvency", solvency.roundToInt(), "Based on liquid assets relative to recorded credit/loan liabilities.")
        )
        return FinancialHealth(components.map { it.score }.average().roundToInt(), components)
    }
}
