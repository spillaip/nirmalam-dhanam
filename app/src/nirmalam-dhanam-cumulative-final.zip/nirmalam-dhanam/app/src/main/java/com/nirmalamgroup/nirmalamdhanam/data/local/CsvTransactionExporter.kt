package com.nirmalamgroup.nirmalamdhanam.data.local

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.ReconciliationStatus
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.TransactionReconciliationEngine

sealed interface CsvImportResult {
    data class Success(val imported: Int, val skippedDuplicates: Int, val possibleMatches: Int, val conflicts: Int) : CsvImportResult
    data class Failure(val message: String, val cause: Throwable? = null) : CsvImportResult
}

/** RFC-4180 compatible transaction CSV export/import with atomic writes and duplicate protection. */
class CsvTransactionExporter(private val context: Context) {
    private val dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    suspend fun exportTo(destination: Uri, transactions: List<TransactionEntity>, accounts: Map<String, String>): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openOutputStream(destination, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
                writer.write(CsvCodec.encodeRecord(listOf("Date", "Type", "Amount", "Category", "Payee", "Account", "Notes")))
                writer.write("\r\n")
                transactions.forEach { t ->
                    val date = Instant.ofEpochMilli(t.occurredAtEpochMs).atZone(ZoneId.systemDefault()).toLocalDate().format(dateFormatter)
                    val type = if (t.direction == TransactionDirection.CREDIT) "Aaya" else "Vyaya"
                    val amount = BigDecimal(t.amountPaise).movePointLeft(2).toPlainString()
                    val fields = listOf(date, type, amount, t.category.orEmpty(), t.payee.orEmpty(), accounts[t.accountId] ?: "Unknown", t.description.orEmpty())
                    writer.write(CsvCodec.encodeRecord(fields))
                    writer.write("\r\n")
                }
            } ?: error("Unable to open CSV destination.")
        }.isSuccess
    }

    suspend fun importFrom(source: Uri, accountId: String, database: NirmalamDatabase): CsvImportResult = withContext(Dispatchers.IO) {
        runCatching {
            require(database.accountDao().getById(accountId) != null) { "Choose a valid destination account." }
            val text = context.contentResolver.openInputStream(source)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: error("Unable to read the selected CSV file.")
            require(text.length <= 32 * 1024 * 1024) { "CSV exceeds the 32 MB safety limit." }
            val records = CsvCodec.parse(text.removePrefix("\uFEFF"))
            require(records.isNotEmpty()) { "CSV is empty." }
            val header = records.first().map { it.trim().lowercase() }
            fun col(name: String): Int = header.indexOf(name).also { require(it >= 0) { "Missing CSV column: $name" } }
            val dateCol = col("date")
            val typeCol = col("type")
            val amountCol = col("amount")
            val categoryCol = header.indexOf("category")
            val payeeCol = header.indexOf("payee")
            val notesCol = header.indexOf("notes")

            val existing = database.transactionDao().getForAccount(accountId)
            val existingCategories = database.categoryDao().getAll().associateBy { it.name.trim().lowercase() }
            val candidates = mutableListOf<TransactionEntity>()
            records.drop(1).filterNot { row -> row.all { it.isBlank() } }.forEachIndexed { index, row ->
                fun value(column: Int): String = if (column >= 0) row.getOrNull(column).orEmpty().trim() else ""
                val date = runCatching { LocalDate.parse(value(dateCol), dateFormatter) }.getOrNull()
                    ?: error("Row ${index + 2}: invalid Date; expected dd/MM/yyyy.")
                val rawType = value(typeCol)
                val direction = when {
                    rawType.equals("Aaya", true) || rawType.equals("Income", true) || rawType.equals("Credit", true) -> TransactionDirection.CREDIT
                    rawType.equals("Vyaya", true) || rawType.equals("Expense", true) || rawType.equals("Debit", true) -> TransactionDirection.DEBIT
                    else -> error("Row ${index + 2}: Type must be Aaya/Vyaya (or Income/Expense).")
                }
                val amountPaise = runCatching {
                    BigDecimal(value(amountCol)).movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValueExact()
                }.getOrNull()?.takeIf { it > 0 } ?: error("Row ${index + 2}: invalid positive Amount.")
                val category = value(categoryCol).ifBlank { if (direction == TransactionDirection.CREDIT) "Income" else "Uncategorised" }
                val payee = value(payeeCol).ifBlank { if (direction == TransactionDirection.CREDIT) "Unlabelled Aaya" else "Unlabelled Vyaya" }
                val description = value(notesCol).ifBlank { null }
                val epochMs = date.atTime(12, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val categoryPriority = existingCategories[category.trim().lowercase()]?.priority ?: CategoryPriority.NEED
                val envelope = when {
                    direction == TransactionDirection.CREDIT -> null
                    categoryPriority == CategoryPriority.WANT -> EnvelopeType.WANTS
                    else -> EnvelopeType.NEEDS
                }
                candidates += TransactionEntity(
                    id = UUID.randomUUID().toString(), accountId = accountId, amountPaise = amountPaise,
                    direction = direction, merchant = payee, category = category, payee = payee,
                    description = description, envelopeType = envelope, occurredAtEpochMs = epochMs
                )
            }

            val accepted = mutableListOf<TransactionEntity>()
            var duplicates = 0
            var possibleMatches = 0
            var conflicts = 0
            val comparisonPool = existing.toMutableList()
            candidates.forEach { candidate ->
                when (TransactionReconciliationEngine.classify(candidate, comparisonPool).status) {
                    ReconciliationStatus.PROBABLE_DUPLICATE -> duplicates++
                    ReconciliationStatus.POSSIBLE_MATCH -> { possibleMatches++; accepted += candidate; comparisonPool += candidate }
                    ReconciliationStatus.CONFLICT -> conflicts++
                    ReconciliationStatus.NEW -> { accepted += candidate; comparisonPool += candidate }
                }
            }

            // Only create supporting metadata for rows that will actually be imported.
            // Rejected duplicates/conflicts must not leave categories or payees behind.
            val categories = accepted.associate { transaction ->
                transaction.category.orEmpty() to transaction.direction
            }
            val payees = accepted.associate { transaction ->
                transaction.payee.orEmpty() to transaction.category
            }

            database.withTransaction {
                categories.forEach { (name, direction) ->
                    if (database.categoryDao().getByName(name) == null) {
                        database.categoryDao().upsert(CategoryEntity("user-imported-${UUID.randomUUID()}", name, direction))
                    }
                }
                payees.forEach { (name, category) ->
                    if (database.payeeDao().getByName(name) == null) {
                        database.payeeDao().upsert(PayeeEntity("payee-imported-${UUID.randomUUID()}", name, category))
                    }
                }
                database.transactionDao().upsertAll(accepted)
            }
            CsvImportResult.Success(accepted.size, duplicates, possibleMatches, conflicts)
        }.getOrElse { error ->
            val detail = error.message?.takeIf { it.isNotBlank() } ?: "Unknown CSV error."
            CsvImportResult.Failure("CSV import failed: $detail No changes were committed.", error)
        }
    }

}
