package com.nirmalamgroup.nirmalamdhanam

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nirmalamgroup.nirmalamdhanam.data.local.AccountKind
import com.nirmalamgroup.nirmalamdhanam.data.local.TransactionDirection
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.*
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

private fun insightMoney(paise: Long, currencyCode: String): String = MoneyFormatter.format(paise, currencyCode)

@Composable
internal fun WhatChangedCard(state: MvpFinanceState) {
    val events = remember(state.allTransactions, state.investmentHistory, state.accounts, state.changesSinceEpochMs) {
        FinancialTimelineBuilder.build(state.allTransactions, state.investmentHistory, state.accounts, state.changesSinceEpochMs)
    }
    if (events.isEmpty()) return
    val txDelta = events.filterIsInstance<FinancialEvent.Transaction>().sumOf {
        if (it.source.direction == TransactionDirection.CREDIT) it.source.amountPaise else -it.source.amountPaise
    }
    val marketDelta = events.filterIsInstance<FinancialEvent.InvestmentCheckIn>().sumOf { it.source.marketMovementPaise }
    ElevatedCard(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("What changed since your last visit?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("${events.size} financial event${if (events.size == 1) "" else "s"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (txDelta != 0L) Text("Net transaction movement  ${insightMoney(txDelta, state.currencyCode)}", style = MaterialTheme.typography.bodyMedium)
            if (marketDelta != 0L) Text("Investment market movement  ${insightMoney(marketDelta, state.currencyCode)}", style = MaterialTheme.typography.bodyMedium)
            events.take(3).forEach { event ->
                HorizontalDivider()
                Text(event.title, style = MaterialTheme.typography.labelLarge)
                Text(event.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun InsightsScreen(
    state: MvpFinanceState,
    onBack: () -> Unit,
    onCreateGoal: (String, String, String, String?) -> Unit,
    onArchiveGoal: (String) -> Unit,
    onRecordTransaction: (String, String, String, String, TransactionDirection, String, Long) -> Unit
) {
    val latest = remember(state.investmentHistory) {
        state.investmentHistory.groupBy { it.accountId }.values.mapNotNull { rows -> rows.maxByOrNull { it.asOfEpochDay } }
    }
    val health = remember(state.accounts, state.accountBalances, state.allTransactions, latest) {
        FinancialHealthCalculator.calculate(state.accounts, state.accountBalances, state.allTransactions, latest)
    }
    val insights = remember(state.allTransactions, state.categories, state.investmentHistory) {
        ExplainableInsightEngine.build(state.allTransactions, state.categories, state.investmentHistory)
    }
    val goalProgress = remember(state.goals, state.goalAllocations, state.accountBalances, latest) {
        GoalProgressCalculator.calculate(state.goals, state.goalAllocations, state.accountBalances, latest)
    }
    val timeline = remember(state.allTransactions, state.investmentHistory, state.accounts) {
        FinancialTimelineBuilder.build(state.allTransactions, state.investmentHistory, state.accounts).take(12)
    }
    var expandedInsight by remember { mutableStateOf<String?>(null) }
    var showGoalDialog by remember { mutableStateOf(false) }
    var timeMachineDate by remember { mutableStateOf(LocalDate.now().toString()) }
    val historical = remember(timeMachineDate, state.accounts, state.allTransactions, state.investmentHistory) {
        runCatching { LocalDate.parse(timeMachineDate) }.getOrNull()?.let {
            FinancialTimeMachine.reconstruct(it, state.accounts, state.allTransactions, state.investmentHistory)
        }
    }
    var copilotInput by remember { mutableStateOf("") }
    var copilotResult by remember { mutableStateOf<CopilotResult?>(null) }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = { TopAppBar(title = { Text("Insights") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }) }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(horizontal = 20.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ElevatedCard(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Financial health", style = MaterialTheme.typography.titleMedium)
                        Text("${health.overallScore}/100", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.SemiBold)
                        health.components.forEach { component ->
                            Text("${component.name} · ${component.score}/100", style = MaterialTheme.typography.labelLarge)
                            LinearProgressIndicator(progress = component.score / 100f, modifier = Modifier.fillMaxWidth())
                            Text(component.explanation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                Text("Explainable signals", style = MaterialTheme.typography.titleMedium)
                if (insights.isEmpty()) Text("No unusual pattern needs attention right now.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    insights.take(5).forEach { insight ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(insight.title, style = MaterialTheme.typography.titleSmall)
                                Text(insight.explanation, style = MaterialTheme.typography.bodyMedium)
                                TextButton(onClick = { expandedInsight = if (expandedInsight == insight.id) null else insight.id }) { Text("Why am I seeing this?") }
                                if (expandedInsight == insight.id) Text(
                                    "Evidence: ${insight.evidenceTransactionIds.size} transaction(s), ${insight.evidenceSnapshotIds.size} investment check-in(s). Dhanam derives this locally from the records shown in the app.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Goals", style = MaterialTheme.typography.titleMedium)
                    TextButton(onClick = { showGoalDialog = true }) { Text("Add goal") }
                }
                if (goalProgress.isEmpty()) Text("Link an existing account or investment to a goal; Dhanam reuses the same balance instead of creating another ledger.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    goalProgress.forEach { progress ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(progress.goal.name, style = MaterialTheme.typography.titleSmall)
                                    Text("${progress.progressPercent.toInt()}%", style = MaterialTheme.typography.labelLarge)
                                }
                                LinearProgressIndicator(progress = (progress.progressPercent / 100.0).toFloat(), modifier = Modifier.fillMaxWidth())
                                Text("${insightMoney(progress.fundedPaise, state.currencyCode)} of ${insightMoney(progress.targetPaise, state.currencyCode)}", style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = { onArchiveGoal(progress.goal.id) }) { Text("Archive") }
                            }
                        }
                    }
                }
            }

            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Financial time machine", style = MaterialTheme.typography.titleMedium)
                        Text("Reconstruct balances from your ledger and the latest investment check-in on or before a date.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedTextField(timeMachineDate, { timeMachineDate = it }, Modifier.fillMaxWidth(), label = { Text("Date · YYYY-MM-DD") }, singleLine = true)
                        historical?.let { snapshot ->
                            Text("Net worth  ${insightMoney(snapshot.netWorthPaise, state.currencyCode)}", style = MaterialTheme.typography.titleSmall)
                            Text("Cash & reserves ${insightMoney(snapshot.cashAndReservesPaise, state.currencyCode)} · Investments ${insightMoney(snapshot.investmentValuePaise, state.currencyCode)} · Liabilities ${insightMoney(snapshot.liabilitiesPaise, state.currencyCode)}", style = MaterialTheme.typography.bodySmall)
                        } ?: Text("Enter a valid date.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Private local copilot", style = MaterialTheme.typography.titleMedium)
                        Text("Read questions and command parsing stay on device. A write is only a preview until you confirm it.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedTextField(copilotInput, { copilotInput = it }, Modifier.fillMaxWidth(), label = { Text("e.g. How much did I spend on travel this year?") })
                        Button(onClick = { copilotResult = LocalFinancialCopilot.interpret(copilotInput, state.allTransactions, state.accounts, state.currencyCode) }, enabled = copilotInput.isNotBlank()) { Text("Ask locally") }
                        when (val result = copilotResult) {
                            is CopilotResult.Answer -> Text(result.text)
                            is CopilotResult.Unsupported -> Text(result.message, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            is CopilotResult.TransactionPreview -> {
                                Text("Preview only", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                Text("${if (result.direction == TransactionDirection.CREDIT) "Income" else "Expense"} ${insightMoney(result.amountPaise, state.currencyCode)} · ${result.payee} · ${result.accountName}")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        onRecordTransaction(BigDecimal(result.amountPaise).movePointLeft(2).toPlainString(), result.payee, result.category, "Created from confirmed local copilot preview", result.direction, result.accountId, result.occurredAtEpochMs)
                                        copilotResult = CopilotResult.Answer("Confirmed. The transaction was submitted through the normal Dhanam transaction rules.")
                                    }) { Text("Confirm") }
                                    TextButton(onClick = { copilotResult = null }) { Text("Cancel") }
                                }
                            }
                            null -> Unit
                        }
                    }
                }
            }

            item {
                Text("Financial timeline", style = MaterialTheme.typography.titleMedium)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    timeline.forEach { event ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(event.title, style = MaterialTheme.typography.labelLarge)
                                Text(event.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(Instant.ofEpochMilli(event.sortEpochMs).atZone(ZoneId.systemDefault()).toLocalDate().toString(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showGoalDialog) GoalDialog(state, onDismiss = { showGoalDialog = false }) { name, target, date, accountId ->
        onCreateGoal(name, target, date, accountId)
        showGoalDialog = false
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GoalDialog(state: MvpFinanceState, onDismiss: () -> Unit, onSave: (String, String, String, String?) -> Unit) {
    var name by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var accountId by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    val linkable = state.accounts.filterNot { it.kind == AccountKind.CREDIT || it.isArchived }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add financial goal") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Goal") }, singleLine = true)
                OutlinedTextField(target, { target = it }, Modifier.fillMaxWidth(), label = { Text("Target amount") }, singleLine = true)
                OutlinedTextField(date, { date = it }, Modifier.fillMaxWidth(), label = { Text("Target date · optional YYYY-MM-DD") }, singleLine = true)
                ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
                    OutlinedTextField(
                        value = linkable.firstOrNull { it.id == accountId }?.name ?: "Link later",
                        onValueChange = {},
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        readOnly = true,
                        label = { Text("Funded by") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }
                    )
                    ExposedDropdownMenu(expanded, { expanded = false }) {
                        DropdownMenuItem(text = { Text("Link later") }, onClick = { accountId = null; expanded = false })
                        linkable.forEach { account -> DropdownMenuItem(text = { Text(account.name) }, onClick = { accountId = account.id; expanded = false }) }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onSave(name, target, date, accountId) }, enabled = name.isNotBlank() && target.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
