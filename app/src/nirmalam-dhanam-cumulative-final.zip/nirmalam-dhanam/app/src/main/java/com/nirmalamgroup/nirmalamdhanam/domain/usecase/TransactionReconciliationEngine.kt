package com.nirmalamgroup.nirmalamdhanam.domain.usecase

import com.nirmalamgroup.nirmalamdhanam.data.local.TransactionEntity
import java.time.Instant
import java.time.ZoneId

/** Deterministic duplicate/conflict classification used by imports and future bank connectors. */
enum class ReconciliationStatus { NEW, PROBABLE_DUPLICATE, POSSIBLE_MATCH, CONFLICT }

data class ReconciliationDecision(
    val status: ReconciliationStatus,
    val matchedTransactionId: String? = null,
    val reason: String
)

object TransactionReconciliationEngine {
    private fun normalise(value: String?): String = value.orEmpty().trim().lowercase().replace(Regex("\\s+"), " ")

    fun classify(candidate: TransactionEntity, existing: List<TransactionEntity>): ReconciliationDecision {
        val idCollision = existing.firstOrNull { it.id == candidate.id }
        if (idCollision != null) {
            return if (idCollision == candidate) {
                ReconciliationDecision(ReconciliationStatus.PROBABLE_DUPLICATE, idCollision.id, "Identical transaction identifier and values already exist.")
            } else {
                ReconciliationDecision(ReconciliationStatus.CONFLICT, idCollision.id, "Transaction identifier already exists with different values.")
            }
        }

        val candidateDate = Instant.ofEpochMilli(candidate.occurredAtEpochMs).atZone(ZoneId.systemDefault()).toLocalDate()
        val amountMatches = existing.filter { it.accountId == candidate.accountId && it.amountPaise == candidate.amountPaise && it.direction == candidate.direction }
        val sameDate = amountMatches.filter {
            Instant.ofEpochMilli(it.occurredAtEpochMs).atZone(ZoneId.systemDefault()).toLocalDate() == candidateDate
        }
        val exact = sameDate.firstOrNull {
            normalise(it.payee ?: it.merchant) == normalise(candidate.payee ?: candidate.merchant) &&
                normalise(it.category) == normalise(candidate.category)
        }
        if (exact != null) return ReconciliationDecision(ReconciliationStatus.PROBABLE_DUPLICATE, exact.id, "Same account, date, amount, direction and payee/category.")
        val close = sameDate.firstOrNull()
        if (close != null) return ReconciliationDecision(ReconciliationStatus.POSSIBLE_MATCH, close.id, "Same account, date, amount and direction but different descriptive fields.")
        return ReconciliationDecision(ReconciliationStatus.NEW, reason = "No matching transaction found.")
    }
}
