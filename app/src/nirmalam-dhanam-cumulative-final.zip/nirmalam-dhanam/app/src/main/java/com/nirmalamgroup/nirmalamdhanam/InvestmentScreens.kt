@file:Suppress("DEPRECATION") // Material 3 version bundled with this project exposes only menuAnchor().

package com.nirmalamgroup.nirmalamdhanam

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.net.toUri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.withTransaction
import com.nirmalamgroup.nirmalamdhanam.data.local.*
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.CoolDownTankInterceptorUseCase
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.MoneyFormatter
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.FinancialCalculations
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.InvestmentPerformanceMetric
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.AccountRolePolicy
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.InvestmentDeltaEngine
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.FinancialTimelineBuilder
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.ExplainableInsightEngine
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.FinancialHealthCalculator
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.GoalProgressCalculator
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.FinancialTimeMachine
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.LocalFinancialCopilot
import com.nirmalamgroup.nirmalamdhanam.domain.usecase.CopilotResult
import com.nirmalamgroup.nirmalamdhanam.ui.components.CoolDownTankCard
import com.nirmalamgroup.nirmalamdhanam.ui.components.NeurodiverseModeToggle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale
import java.util.UUID


@Composable
@OptIn(ExperimentalMaterial3Api::class)
internal fun NetWorthDashboardScreen(state: MvpFinanceState, onBack: () -> Unit, onOpenPortfolio: () -> Unit) {
    val latestByInvestment = state.investmentHistory.groupBy { it.accountId }.mapValues { (_, values) -> values.maxBy { it.asOfEpochDay } }
    val spending = state.accountBalances.filter { it.kind == AccountKind.SPENDING }.sumOf { it.balancePaise }
    val reserves = state.accountBalances.filter { it.kind == AccountKind.SAVINGS || it.kind == AccountKind.EMERGENCY }.sumOf { it.balancePaise }
    val liabilities = state.accountBalances.filter { it.kind == AccountKind.CREDIT }.sumOf { (-it.balancePaise).coerceAtLeast(0) }
    val investments = latestByInvestment.values.sumOf { it.currentValuePaise }
    val netWorth = spending + reserves + investments - liabilities
    val assetTotal = spending + reserves + investments
    val accountById = state.accounts.associateBy { it.id }
    val allocationByClass = latestByInvestment.entries.groupBy { (id, _) -> accountById[id]?.assetClass ?: AssetClass.OTHER }
        .mapValues { (_, entries) -> entries.sumOf { it.value.currentValuePaise } }
    val trend = state.netWorthHistory.sortedBy { it.asOfEpochDay }.map { it.netWorthPaise }.let { history -> if (history.lastOrNull() == netWorth) history else history + netWorth }
    val latestTrendDelta = trendDelta(trend)
    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = { TopAppBar(title = { Column { Text("Sampada"); Text("Your net worth dashboard", style = MaterialTheme.typography.labelMedium) } }, navigationIcon = { IconButton(onClick = onBack) { Icon(StandardBackIcon, contentDescription = "Back") } }, actions = { TextButton(onClick = onOpenPortfolio) { Text("Nivesha") } }) }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).padding(horizontal = 20.dp), contentPadding = PaddingValues(vertical = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CURRENT NET WORTH", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(formatMoney(netWorth, state.currencyCode), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("Assets ${formatMoney(assetTotal, state.currencyCode)} · Liabilities ${formatMoney(liabilities, state.currencyCode)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Nivesha cost & value", style = MaterialTheme.typography.titleMedium)
                        Text("Your dated check-ins show invested cost against current value.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        PortfolioValueChart(state.investmentHistory, state.currencyCode)
                    }
                }
            }
            latestTrendDelta?.let { delta ->
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Latest Sampada move", style = MaterialTheme.typography.titleMedium)
                                Text("Compared with the previous dated snapshot", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(formatMoney(delta, state.currencyCode, includeSign = true), style = MaterialTheme.typography.titleMedium, color = if (delta < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, maxLines = 1)
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ElevatedCard(Modifier.weight(1f)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { Text("LIQUID", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(formatMoney(spending, state.currencyCode), style = MaterialTheme.typography.titleLarge); Text("Cash & bank", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
                    ElevatedCard(Modifier.weight(1f)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { Text("RESERVES", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(formatMoney(reserves, state.currencyCode), style = MaterialTheme.typography.titleLarge); Text("Savings & emergency", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Nivesha & liabilities", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Investment assets"); Text(formatMoney(investments, state.currencyCode), style = MaterialTheme.typography.titleSmall) }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Credit & loans"); Text(formatMoney(-liabilities, state.currencyCode), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error) }
                    TextButton(onClick = onOpenPortfolio, modifier = Modifier.fillMaxWidth()) { Text("Manage Nivesha") }
                } }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Sampada trend", style = MaterialTheme.typography.titleMedium)
                    if (trend.size >= 2) NetWorthSparkline(trend) else Text("Your trend grows as you record monthly Nivesha balances.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } }
            }
            item { Text("Nivesha by asset class", style = MaterialTheme.typography.titleMedium) }
            if (allocationByClass.isEmpty()) item { ElevatedCard(Modifier.fillMaxWidth()) { Text("Add an investment asset and its first check-in to see allocation here.", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium) } }
            items(allocationByClass.entries.sortedByDescending { it.value }.size) { index ->
                val (assetClass, amount) = allocationByClass.entries.sortedByDescending { it.value }[index]
                val share = if (investments == 0L) 0f else (amount.toDouble() / investments).toFloat()
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(assetClass.name.replace('_', ' '), style = MaterialTheme.typography.titleSmall); Text(formatMoney(amount, state.currencyCode), style = MaterialTheme.typography.titleSmall) }
                    LinearProgressIndicator(progress = { share }, modifier = Modifier.fillMaxWidth())
                    Text("${"%.1f".format(share * 100)}% of Nivesha", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } }
            }
            item { Text("How Sampada is calculated", style = MaterialTheme.typography.titleMedium) }
            item { Text("Liquid cash + reserves + latest Nivesha values − credit and loan liabilities. Dated Nivesha check-ins provide the historical trend; everyday cashflow updates the current total instantly.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
internal fun PortfolioAndNetWorthScreen(state: MvpFinanceState, onBack: () -> Unit, onOpenNetWorth: () -> Unit, onOpenPerformanceReport: () -> Unit, onAddInvestment: () -> Unit, onRecordBalance: () -> Unit, onDeleteSnapshot: (String) -> Unit, onUpdateSnapshot: (String, String, String, String, String, String) -> Unit, onUpdateInvestment: (String, String, AccountProductType, AssetClass, String) -> Unit, onArchiveInvestment: (String) -> Unit) {
    var editingSnapshotId by remember { mutableStateOf<String?>(null) }
    var editingInvestmentId by remember { mutableStateOf<String?>(null) }
    var investmentToArchive by remember { mutableStateOf<AccountEntity?>(null) }
    val latestByAsset = state.investmentHistory.groupBy { it.accountId }.mapValues { (_, snapshots) -> snapshots.maxBy { it.asOfEpochDay } }
    val historyByInvestment = state.investmentHistory.groupBy { it.accountId }
    val portfolioValue = latestByAsset.values.sumOf { it.currentValuePaise }
    val portfolioCost = latestByAsset.values.sumOf { it.totalCostPaise }
    val portfolioAbsolutePaise = portfolioValue - portfolioCost
    val portfolioAbsolutePercent = portfolioCost.takeIf { it != 0L }?.let { portfolioAbsolutePaise * 100.0 / it }
    val portfolioXirr = FinancialCalculations.xirrPercent(historyByInvestment.values.flatMap(::cashFlowsForXirr))
    val portfolioTrendDelta = trendDelta(portfolioChartPoints(state.investmentHistory).map { it.valuePaise })
    val netWorth = state.netWorthHistory.maxByOrNull { it.asOfEpochDay }?.netWorthPaise ?: run {
        val reserves = state.accountBalances.filter { it.kind == AccountKind.SAVINGS || it.kind == AccountKind.EMERGENCY }.sumOf { it.balancePaise }
        state.cashPaise + reserves + portfolioValue
    }
    Scaffold(contentWindowInsets = WindowInsets.safeDrawing, topBar = { TopAppBar(title = { Column { Text("Nivesha & Sampada"); Text("Investments and overall wealth", style = MaterialTheme.typography.labelMedium) } }, navigationIcon = { IconButton(onClick = onBack) { Icon(StandardBackIcon, contentDescription = "Back") } }, actions = { TextButton(onClick = onOpenPerformanceReport) { Text("Performance") }; TextButton(onClick = onOpenNetWorth) { Text("Sampada") }; TextButton(onClick = onAddInvestment) { Text("Add") }; TextButton(onClick = onRecordBalance) { Text("Check-in") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(horizontal = 20.dp), contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("SAMPADA · NET WORTH", style = MaterialTheme.typography.labelLarge)
                        Text(formatMoney(netWorth, state.currencyCode), style = MaterialTheme.typography.displaySmall)
                        HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.15f))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text("NIVESHA VALUE", style = MaterialTheme.typography.labelSmall); Text(formatMoney(portfolioValue, state.currencyCode), style = MaterialTheme.typography.titleMedium) }
                            Column(horizontalAlignment = Alignment.End) { Text("TOTAL RETURN", style = MaterialTheme.typography.labelSmall); Text("${formatMoney(portfolioAbsolutePaise, state.currencyCode, includeSign = true)} · ABS ${formatPercent(portfolioAbsolutePercent)}", style = MaterialTheme.typography.titleSmall, color = if (portfolioAbsolutePaise < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onPrimaryContainer); Text("XIRR ${formatPercent(portfolioXirr)}", style = MaterialTheme.typography.labelSmall) }
                        }
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Sampada trend", style = MaterialTheme.typography.titleMedium)
                    if (state.netWorthHistory.size >= 2) NetWorthSparkline(state.netWorthHistory.sortedBy { it.asOfEpochDay }.map { it.netWorthPaise }) else Text("Your trend appears after two dated investment check-ins.", style = MaterialTheme.typography.bodySmall)
                } }
            }
            portfolioTrendDelta?.let { delta ->
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Latest Nivesha move", style = MaterialTheme.typography.titleMedium)
                                Text("Change from the previous portfolio check-in", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(formatMoney(delta, state.currencyCode, includeSign = true), style = MaterialTheme.typography.titleMedium, color = if (delta < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, maxLines = 1)
                        }
                    }
                }
            }
            item { Text("Nivesha allocation", style = MaterialTheme.typography.titleMedium) }
            items(latestByAsset.size) { index ->
                val (accountId, snapshot) = latestByAsset.entries.sortedByDescending { it.value.currentValuePaise }[index]
                val account = state.accounts.firstOrNull { it.id == accountId }
                val allocation = if (portfolioValue == 0L) 0.0 else snapshot.currentValuePaise * 100.0 / portfolioValue
                val performance = investmentPerformance(historyByInvestment[accountId].orEmpty())
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) { Text(account?.name ?: "Investment", style = MaterialTheme.typography.titleSmall); Text(account?.productType?.name?.replace('_', ' ') ?: "Asset", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant); account?.benchmarkIndexName?.let { Text("Benchmark · $it", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }; Text("Cost ${formatMoney(snapshot.totalCostPaise, state.currencyCode)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Column(horizontalAlignment = Alignment.End) { Text(formatMoney(snapshot.currentValuePaise, state.currencyCode), style = MaterialTheme.typography.titleMedium); Text("${"%.1f".format(allocation)}% allocation · ABS ${formatPercent(performance?.absolutePercent)}", style = MaterialTheme.typography.bodySmall, color = if ((performance?.absolutePaise ?: 0L) < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary); Text("XIRR ${formatPercent(performance?.xirrPercent)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    account?.let { investment ->
                        if (editingInvestmentId == investment.id) InlineInvestmentEditor(investment, onCancel = { editingInvestmentId = null }, onSave = { name, product, assetClass, target -> onUpdateInvestment(investment.id, name, product, assetClass, target); editingInvestmentId = null })
                        else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = { editingInvestmentId = investment.id }) { Text("Modify") }; TextButton(onClick = { investmentToArchive = investment }) { Text("Archive") } }
                    }
                } }
            }
            val unvaluedInvestments = state.accounts.filter { it.kind == AccountKind.INVESTMENT && it.id !in latestByAsset }
            if (unvaluedInvestments.isNotEmpty()) item { Text("Awaiting first check-in", style = MaterialTheme.typography.titleMedium) }
            items(unvaluedInvestments.size) { index ->
                val investment = unvaluedInvestments[index]
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(investment.name, style = MaterialTheme.typography.titleSmall)
                    Text("${investment.productType.name.replace('_', ' ')} · no valuation recorded yet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (editingInvestmentId == investment.id) InlineInvestmentEditor(investment, onCancel = { editingInvestmentId = null }, onSave = { name, product, assetClass, target -> onUpdateInvestment(investment.id, name, product, assetClass, target); editingInvestmentId = null })
                    else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = { editingInvestmentId = investment.id }) { Text("Modify") }; TextButton(onClick = { investmentToArchive = investment }) { Text("Archive") } }
                } }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Nivesha allocation vs target", style = MaterialTheme.typography.titleMedium)
                    AssetClass.entries.filter { assetClass -> state.accounts.any { it.assetClass == assetClass && it.targetAllocationBps > 0 } }.forEach { assetClass ->
                        val actualValue = latestByAsset.entries.filter { (accountId, _) -> state.accounts.firstOrNull { it.id == accountId }?.assetClass == assetClass }.sumOf { it.value.currentValuePaise }
                        val actual = if (portfolioValue == 0L) 0.0 else actualValue * 100.0 / portfolioValue
                        val target = state.accounts.filter { it.assetClass == assetClass }.sumOf { it.targetAllocationBps } / 100.0
                        val difference = actual - target
                        Text("${assetClass.name}: %.1f%% / %.1f%% target · %s %.1f%%".format(actual, target, if (difference >= 0) "over" else "under", kotlin.math.abs(difference)), style = MaterialTheme.typography.bodySmall)
                    }
                } }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Nivesha history", style = MaterialTheme.typography.titleMedium)
                    Text("Dated cost and value check-ins", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            val history = state.investmentHistory.sortedWith(compareByDescending<InvestmentBalanceSnapshotEntity> { it.asOfEpochDay }.thenByDescending { it.createdAtEpochMs })
            items(history.size) { index ->
                val snapshot = history[index]
                val account = state.accounts.firstOrNull { it.id == snapshot.accountId }
                val performance = investmentPerformance(historyByInvestment[snapshot.accountId].orEmpty().filter { it.asOfEpochDay <= snapshot.asOfEpochDay })
                val gain = performance?.absolutePaise
                    ?: (snapshot.currentValuePaise - snapshot.totalCostPaise)
                val gainColor = if (gain < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                ElevatedCard(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(account?.name ?: "Investment", style = MaterialTheme.typography.titleSmall)
                            Text(account?.productType?.name?.replace('_', ' ') ?: "Nivesha holding", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            account?.benchmarkIndexName?.let { benchmark -> Text("Benchmark · $benchmark", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("AS ON", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text(formatDate(LocalDate.ofEpochDay(snapshot.asOfEpochDay), state.dateFormatPreference), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Box(Modifier.weight(1f)) { InvestmentHistoryMetric("COST", formatMoney(snapshot.totalCostPaise, state.currencyCode)) }
                        Box(Modifier.weight(1f)) { InvestmentHistoryMetric("VALUE", formatMoney(snapshot.currentValuePaise, state.currencyCode), alignment = Alignment.CenterHorizontally) }
                        Box(Modifier.weight(1f)) { InvestmentHistoryMetric("GAIN / LOSS", formatMoney(gain, state.currencyCode, includeSign = true), gainColor, Alignment.End) }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ABS ${formatPercent(performance?.absolutePercent)}", style = MaterialTheme.typography.labelMedium, color = gainColor)
                        Text("XIRR ${formatPercent(performance?.xirrPercent)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    AssistChip(
                        onClick = {},
                        label = { Text("Net contribution ${formatMoney(snapshot.netContributionPaise, state.currencyCode, includeSign = true)}") }
                    )
                    snapshot.note?.takeIf { it.isNotBlank() }?.let { note ->
                        Text(note, Modifier.fillMaxWidth(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (editingSnapshotId == snapshot.id) {
                        InlineInvestmentSnapshotEditor(
                            snapshot = snapshot,
                            investmentHistory = state.investmentHistory,
                            dateFormatPreference = state.dateFormatPreference,
                            onCancel = { editingSnapshotId = null },
                            onSave = { date, cost, value, note ->
                                onUpdateSnapshot(snapshot.id, snapshot.accountId, date, cost, value, note)
                                editingSnapshotId = null
                            }
                        )
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { editingSnapshotId = snapshot.id }) { Text("Modify") }
                            TextButton(onClick = { onDeleteSnapshot(snapshot.id) }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Delete") }
                        }
                    }
                } }
            }
        }
    }
    investmentToArchive?.let { account -> AlertDialog(onDismissRequest = { investmentToArchive = null }, title = { Text("Archive Nivesha?") }, text = { Text("${account.name} will be hidden from active portfolio tracking. Its dated history remains safely in this encrypted database.") }, confirmButton = { Button(onClick = { onArchiveInvestment(account.id); investmentToArchive = null }) { Text("Archive") } }, dismissButton = { TextButton(onClick = { investmentToArchive = null }) { Text("Cancel") } }) }
}

@Composable
private fun InvestmentHistoryMetric(label: String, value: String, color: Color = MaterialTheme.colorScheme.onSurface, alignment: Alignment.Horizontal = Alignment.Start) {
    Column(horizontalAlignment = alignment) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleSmall, color = color, maxLines = 1)
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun InlineInvestmentEditor(account: AccountEntity, onCancel: () -> Unit, onSave: (String, AccountProductType, AssetClass, String) -> Unit) {
    var name by remember(account.id) { mutableStateOf(account.name) }
    var product by remember(account.id) { mutableStateOf(account.productType) }
    var assetClass by remember(account.id) { mutableStateOf(account.assetClass) }
    var target by remember(account.id) { mutableStateOf((account.targetAllocationBps / 100.0).toString()) }
    var productExpanded by remember(account.id) { mutableStateOf(false) }
    var classExpanded by remember(account.id) { mutableStateOf(false) }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    Text("Modify Nivesha", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Nivesha name") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), singleLine = true)
    ExposedDropdownMenuBox(productExpanded, { productExpanded = !productExpanded }) {
        OutlinedTextField(product.name.replace('_', ' '), {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Product type") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(productExpanded) })
        ExposedDropdownMenu(productExpanded, { productExpanded = false }) { investmentProductTypes.forEach { type -> DropdownMenuItem(text = { Text(type.name.replace('_', ' ')) }, onClick = { product = type; assetClass = suggestedAssetClass(type); productExpanded = false }) } }
    }
    ExposedDropdownMenuBox(classExpanded, { classExpanded = !classExpanded }) {
        OutlinedTextField(assetClass.name, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Asset class") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(classExpanded) })
        ExposedDropdownMenu(classExpanded, { classExpanded = false }) { AssetClass.entries.forEach { type -> DropdownMenuItem(text = { Text(type.name) }, onClick = { assetClass = type; classExpanded = false }) } }
    }
    OutlinedTextField(target, { target = it }, Modifier.fillMaxWidth(), label = { Text("Target allocation (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = onCancel) { Text("Cancel") }; Button(onClick = { onSave(name, product, assetClass, target) }, enabled = name.isNotBlank()) { Text("Save") } }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun InlineInvestmentSnapshotEditor(snapshot: InvestmentBalanceSnapshotEntity, investmentHistory: List<InvestmentBalanceSnapshotEntity>, dateFormatPreference: DateFormatPreference, onCancel: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var date by remember(snapshot.id) { mutableStateOf(LocalDate.ofEpochDay(snapshot.asOfEpochDay)) }
    var cost by remember(snapshot.id) { mutableStateOf(BigDecimal(snapshot.totalCostPaise).movePointLeft(2).toPlainString()) }
    var value by remember(snapshot.id) { mutableStateOf(BigDecimal(snapshot.currentValuePaise).movePointLeft(2).toPlainString()) }
    var note by remember(snapshot.id) { mutableStateOf(snapshot.note.orEmpty()) }
    val priorSnapshot = remember(snapshot.accountId, date, investmentHistory) {
        investmentHistory.filter { it.accountId == snapshot.accountId && it.asOfEpochDay < date.toEpochDay() && it.id != snapshot.id }.maxByOrNull { it.asOfEpochDay }
    }
    fun rupeesToPaise(text: String) = runCatching { BigDecimal(text.trim()).movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValueExact() }.getOrNull()
    val calculatedDelta = remember(cost, value, priorSnapshot) {
        val c = rupeesToPaise(cost); val v = rupeesToPaise(value)
        if (c != null && v != null && c >= 0 && v >= 0) InvestmentDeltaEngine.calculate(priorSnapshot, c, v) else null
    }
    var showDatePicker by remember(snapshot.id) { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = LocalDate.ofEpochDay(snapshot.asOfEpochDay).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    Text("Modify check-in", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    OutlinedTextField(value = formatDate(date, dateFormatPreference), onValueChange = {}, modifier = Modifier.fillMaxWidth(), readOnly = true, label = { Text("As-on date") }, trailingIcon = { TextButton(onClick = { showDatePicker = true }) { Text("Pick") } }, singleLine = true)
    OutlinedTextField(cost, { cost = it }, Modifier.fillMaxWidth(), label = { Text("Total cost in ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
    OutlinedTextField(value, { value = it }, Modifier.fillMaxWidth(), label = { Text("Current value in ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
    calculatedDelta?.let { delta ->
        Text("Calculated contribution ${formatMoney(delta.netContributionPaise, "INR", includeSign = true)} · market movement ${formatMoney(delta.marketMovementPaise, "INR", includeSign = true)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("Statement / note") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), singleLine = true)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = onCancel) { Text("Cancel") }; Button(onClick = { onSave(date.toString(), cost, value, note) }) { Text("Save") } }
    if (showDatePicker) {
        DatePickerDialog(onDismissRequest = { showDatePicker = false }, confirmButton = { TextButton(onClick = { datePickerState.selectedDateMillis?.let { date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() }; showDatePicker = false }) { Text("OK") } }, dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }) { DatePicker(state = datePickerState) }
    }
}

@Composable
internal fun NetWorthSparkline(values: List<Long>) {
    val lineColor = MaterialTheme.colorScheme.primary
    val fillColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
    Canvas(Modifier.fillMaxWidth().height(88.dp)) {
        val min = values.minOrNull() ?: 0L
        val max = values.maxOrNull() ?: (min + 1L)
        val spread = (max - min).coerceAtLeast(1L).toFloat()
        val path = Path()
        val fill = Path()
        values.forEachIndexed { index, value ->
            val x = if (values.size == 1) 0f else size.width * index / (values.size - 1)
            val y = size.height - ((value - min) / spread * size.height)
            if (index == 0) {
                path.moveTo(x, y)
                fill.moveTo(x, size.height)
                fill.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(size.width, size.height)
        fill.close()
        drawPath(fill, fillColor)
        drawPath(path, lineColor, style = Stroke(width = 5f, cap = StrokeCap.Round))
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
internal fun AccountSetupDialog(initialProduct: AccountProductType = AccountProductType.CASH, onDismiss: () -> Unit, onSave: (String, AccountProductType, AssetClass, String, String, AccountKind) -> Unit) {
    var name by remember { mutableStateOf("") }
    var openingBalance by remember { mutableStateOf("") }
    var product by remember(initialProduct) { mutableStateOf(initialProduct) }
    var assetClass by remember(initialProduct) { mutableStateOf(suggestedAssetClass(initialProduct)) }
    var expanded by remember { mutableStateOf(false) }
    var assetClassExpanded by remember { mutableStateOf(false) }
    var targetPercent by remember { mutableStateOf("0") }
    var cashKind by remember { mutableStateOf(AccountKind.SPENDING) }
    val isInvestment = product in investmentProductTypes
    val purpose = when {
        isInvestment -> "Investment holding: record dated cost and value check-ins in Nivesha. It does not become daily Aaya or Vyaya."
        product == AccountProductType.CREDIT_CARD || product == AccountProductType.LOAN -> "Liability Khata: record what you owe. Its balance reduces true available cash."
        cashKind == AccountKind.SAVINGS -> "Savings Khata: keep planned reserves separate from day-to-day spending while retaining them in liquidity and health reports."
        cashKind == AccountKind.EMERGENCY -> "Emergency Khata: ring-fence emergency reserves so runway and financial-health reports can identify them explicitly."
        else -> "Daily Khata: use this cash or bank place for Aaya, Vyaya, and your everyday balance."
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set up Khata") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Set up a daily Khata, a liability, or an investment holding.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Khata name") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), singleLine = true)
                ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
                    OutlinedTextField(product.name.replace('_', ' '), {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Khata type") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                    ExposedDropdownMenu(expanded, { expanded = false }) {
                        Text("DAILY KHATAS", modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), style = MaterialTheme.typography.labelSmall)
                        listOf(AccountProductType.CASH, AccountProductType.BANK).forEach { type -> DropdownMenuItem(text = { Text(type.name.replace('_', ' ')) }, onClick = { product = type; assetClass = suggestedAssetClass(type); expanded = false }) }
                        HorizontalDivider()
                        Text("LIABILITIES", modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), style = MaterialTheme.typography.labelSmall)
                        listOf(AccountProductType.CREDIT_CARD, AccountProductType.LOAN).forEach { type -> DropdownMenuItem(text = { Text(type.name.replace('_', ' ')) }, onClick = { product = type; assetClass = suggestedAssetClass(type); expanded = false }) }
                        HorizontalDivider()
                        Text("INVESTMENT HOLDINGS", modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), style = MaterialTheme.typography.labelSmall)
                        investmentProductTypes.forEach { type -> DropdownMenuItem(text = { Text(type.name.replace('_', ' ')) }, onClick = { product = type; assetClass = suggestedAssetClass(type); expanded = false }) }
                    }
                }
                ElevatedCard(Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Text(purpose, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (product == AccountProductType.CASH || product == AccountProductType.BANK) {
                    Text("Purpose", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AccountRolePolicy.cashAccountKinds.map { kind -> kind to when (kind) { AccountKind.SPENDING -> "Daily"; AccountKind.SAVINGS -> "Savings"; AccountKind.EMERGENCY -> "Emergency"; else -> kind.name } }.forEach { (kind, label) ->
                            FilterChip(selected = cashKind == kind, onClick = { cashKind = kind }, label = { Text(label) })
                        }
                    }
                }
                if (isInvestment) {
                    ExposedDropdownMenuBox(assetClassExpanded, { assetClassExpanded = !assetClassExpanded }) {
                        OutlinedTextField(assetClass.name, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Asset class") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(assetClassExpanded) })
                        ExposedDropdownMenu(assetClassExpanded, { assetClassExpanded = false }) {
                            AssetClass.entries.forEach { type -> DropdownMenuItem(text = { Text(type.name) }, onClick = { assetClass = type; assetClassExpanded = false }) }
                        }
                    }
                    OutlinedTextField(targetPercent, { targetPercent = it }, Modifier.fillMaxWidth(), label = { Text("Target allocation (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
                OutlinedTextField(openingBalance, { openingBalance = it }, Modifier.fillMaxWidth(), label = { Text(if (isInvestment) "Starting cost / value in ₹" else if (product == AccountProductType.CREDIT_CARD || product == AccountProductType.LOAN) "Current amount owed in ₹" else "Opening balance in ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            }
        },
        confirmButton = { Button(onClick = { onSave(name, product, assetClass, targetPercent, openingBalance, cashKind) }, enabled = name.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
internal fun InvestmentBalanceCheckInDialog(accounts: List<AccountEntity>, investmentHistory: List<InvestmentBalanceSnapshotEntity>, dateFormatPreference: DateFormatPreference, initialAccountId: String? = null, onDismiss: () -> Unit, onSave: (String, String, String, String, String) -> Unit) {
    if (accounts.isEmpty()) return
    var account by remember(accounts, initialAccountId) { mutableStateOf(accounts.firstOrNull { it.id == initialAccountId } ?: accounts.first()) }
    var accountExpanded by remember { mutableStateOf(false) }
    var asOfDate by remember { mutableStateOf(LocalDate.now()) }
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = LocalDate.now().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
    var cost by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val priorSnapshot = remember(account, asOfDate, investmentHistory) { investmentHistory.filter { it.accountId == account.id && it.asOfEpochDay < asOfDate.toEpochDay() }.maxByOrNull { it.asOfEpochDay } }
    fun rupeesToPaise(text: String) = runCatching { BigDecimal(text.trim()).movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValueExact() }.getOrNull()
    val calculatedDelta = remember(cost, value, priorSnapshot) {
        val c = rupeesToPaise(cost); val v = rupeesToPaise(value)
        if (c != null && v != null && c >= 0 && v >= 0) InvestmentDeltaEngine.calculate(priorSnapshot, c, v) else null
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Investment balance check-in") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Enter current cost and current value. Dhanam calculates contribution/withdrawal and market movement from the previous check-in.", style = MaterialTheme.typography.bodySmall)
            ExposedDropdownMenuBox(accountExpanded, { accountExpanded = !accountExpanded }) {
                OutlinedTextField(account.name, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Nivesha") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(accountExpanded) })
                ExposedDropdownMenu(accountExpanded, { accountExpanded = false }) { accounts.forEach { item -> DropdownMenuItem(text = { Text("${item.productType.name.replace('_', ' ')} · ${item.name}") }, onClick = { account = item; accountExpanded = false }) } }
            }
            OutlinedTextField(value = formatDate(asOfDate, dateFormatPreference), onValueChange = {}, modifier = Modifier.fillMaxWidth(), readOnly = true, label = { Text("As-on date") }, trailingIcon = { TextButton(onClick = { showDatePicker = true }) { Text("Pick") } }, singleLine = true)
            OutlinedTextField(cost, { cost = it }, Modifier.fillMaxWidth(), label = { Text("Current cost / principal in ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(value, { value = it }, Modifier.fillMaxWidth(), label = { Text("Current value in ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            calculatedDelta?.let { delta -> ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Calculated automatically", style = MaterialTheme.typography.labelMedium)
                Text("Contribution / withdrawal: ${formatMoney(delta.netContributionPaise, "INR", includeSign = true)}", style = MaterialTheme.typography.bodySmall)
                Text("Market movement: ${formatMoney(delta.marketMovementPaise, "INR", includeSign = true)}", style = MaterialTheme.typography.bodySmall)
                Text("Unrealised gain/loss: ${formatMoney(delta.unrealizedGainPaise, "INR", includeSign = true)}", style = MaterialTheme.typography.bodySmall)
            } } }
            OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("Statement / note (optional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), singleLine = true)
        } },
        confirmButton = { Button(onClick = { onSave(account.id, asOfDate.toString(), cost, value, note) }, enabled = cost.isNotBlank() && value.isNotBlank()) { Text("Save balance") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
    if (showDatePicker) {
        DatePickerDialog(onDismissRequest = { showDatePicker = false }, confirmButton = { TextButton(onClick = { datePickerState.selectedDateMillis?.let { selected -> asOfDate = Instant.ofEpochMilli(selected).atZone(ZoneOffset.UTC).toLocalDate() }; showDatePicker = false }) { Text("OK") } }, dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }) { DatePicker(state = datePickerState) }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
internal fun InvestmentContributionDialog(accounts: List<AccountEntity>, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var account by remember(accounts) { mutableStateOf(accounts.first()) }
    var expanded by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    var payee by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Contribute to investment") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("This records Vyaya from your cash/bank Khata and increases the selected Nivesha cost and value today.", style = MaterialTheme.typography.bodySmall)
            ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
                OutlinedTextField(account.name, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Nivesha") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                ExposedDropdownMenu(expanded, { expanded = false }) { accounts.forEach { item -> DropdownMenuItem(text = { Text(item.name) }, onClick = { account = item; expanded = false }) } }
            }
            OutlinedTextField(amount, { amount = it }, Modifier.fillMaxWidth(), label = { Text("Contribution in ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(payee, { payee = it }, Modifier.fillMaxWidth(), label = { Text("Provider / payee (optional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), singleLine = true)
        } },
        confirmButton = { Button(onClick = { onSave(account.id, amount, payee) }, enabled = amount.isNotBlank()) { Text("Record contribution") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
