package com.nirmalamgroup.nirmalamdhanam.domain.usecase

import com.nirmalamgroup.nirmalamdhanam.data.local.CategoryEntity
import com.nirmalamgroup.nirmalamdhanam.data.local.InvestmentBalanceSnapshotEntity
import com.nirmalamgroup.nirmalamdhanam.data.local.TransactionDirection
import com.nirmalamgroup.nirmalamdhanam.data.local.TransactionEntity
import com.nirmalamgroup.nirmalamdhanam.data.local.EnvelopeType
import java.time.Instant
import java.time.ZoneId

/** Insight text plus evidence references for an explicit "Why am I seeing this?" drill-down. */
data class FinancialInsight(
    val id: String,
    val title: String,
    val explanation: String,
    val evidenceTransactionIds: List<String> = emptyList(),
    val evidenceSnapshotIds: List<String> = emptyList()
)

object ExplainableInsightEngine {
    private fun money(paise: Long): String = "₹%,.2f".format(paise / 100.0)

    fun build(
        transactions: List<TransactionEntity>,
        categories: List<CategoryEntity>,
        snapshots: List<InvestmentBalanceSnapshotEntity>,
        nowEpochMs: Long = System.currentTimeMillis()
    ): List<FinancialInsight> {
        val zone = ZoneId.systemDefault()
        val today = Instant.ofEpochMilli(nowEpochMs).atZone(zone).toLocalDate()
        val currentStart = today.minusDays(30).atStartOfDay(zone).toInstant().toEpochMilli()
        val priorStart = today.minusDays(60).atStartOfDay(zone).toInstant().toEpochMilli()
        val debits = transactions.filter { it.direction == TransactionDirection.DEBIT && it.envelopeType != EnvelopeType.INVESTMENT && !it.isHoldingTank }
        val current = debits.filter { it.occurredAtEpochMs >= currentStart }
        val previous = debits.filter { it.occurredAtEpochMs in priorStart until currentStart }
        val insights = mutableListOf<FinancialInsight>()

        val categoriesNow = current.groupBy { it.category ?: "Uncategorised" }.mapValues { (_, rows) -> rows.sumOf { it.amountPaise } }
        val categoriesBefore = previous.groupBy { it.category ?: "Uncategorised" }.mapValues { (_, rows) -> rows.sumOf { it.amountPaise } }
        categoriesNow.entries
            .mapNotNull { (category, amount) ->
                val before = categoriesBefore[category] ?: 0L
                if (before <= 0 || amount <= before * 1.25) null else Triple(category, amount, before)
            }
            .sortedByDescending { it.second - it.third }
            .take(3)
            .forEach { (category, amount, before) ->
                val pct = ((amount - before) * 100.0 / before).toInt()
                val evidence = current.filter { (it.category ?: "Uncategorised") == category }.sortedByDescending { it.amountPaise }.take(10)
                insights += FinancialInsight(
                    id = "category-rise-${category.lowercase().replace(Regex("[^a-z0-9]+"), "-")}",
                    title = "$category spending increased",
                    explanation = "Last 30 days are $pct% above the preceding 30 days (${money(amount)} vs ${money(before)}).",
                    evidenceTransactionIds = evidence.map { it.id }
                )
            }

        val wants = categories.filter { it.priority.name == "WANT" }.map { it.name }.toSet()
        val wantSpend = current.filter { it.category in wants }.sumOf { it.amountPaise }
        val totalSpend = current.sumOf { it.amountPaise }
        if (totalSpend > 0 && wantSpend * 100 / totalSpend >= 35) {
            insights += FinancialInsight(
                id = "wants-share",
                title = "Lifestyle spending is a large share of recent expenses",
                explanation = "Want-category spending is ${wantSpend * 100 / totalSpend}% of confirmed debits in the last 30 days.",
                evidenceTransactionIds = current.filter { it.category in wants }.map { it.id }
            )
        }

        snapshots.groupBy { it.accountId }.forEach { (accountId, history) ->
            val ordered = history.sortedByDescending { it.asOfEpochDay }
            if (ordered.size >= 3 && ordered.take(3).all { it.marketMovementPaise < 0 }) {
                insights += FinancialInsight(
                    id = "three-negative-$accountId",
                    title = "Three consecutive negative investment updates",
                    explanation = "The latest three check-ins for this asset recorded negative market movement after adjusting for contributions/withdrawals.",
                    evidenceSnapshotIds = ordered.take(3).map { it.id }
                )
            }
        }
        return insights
    }
}
