package com.nirmalamgroup.nirmalamdhanam.domain.usecase

import com.nirmalamgroup.nirmalamdhanam.data.local.InvestmentBalanceSnapshotEntity

/**
 * Turns a user-entered (cost, current value) pair into an auditable balance delta.
 * No contribution field is accepted from the user: contribution/withdrawal is the cost change.
 */
data class InvestmentDelta(
    val previousCostPaise: Long?,
    val previousValuePaise: Long?,
    val costDeltaPaise: Long,
    val valueDeltaPaise: Long,
    val netContributionPaise: Long,
    val marketMovementPaise: Long,
    val unrealizedGainPaise: Long
) {
    val contributionPaise: Long get() = netContributionPaise.coerceAtLeast(0)
    val withdrawalPaise: Long get() = (-netContributionPaise).coerceAtLeast(0)
}

object InvestmentDeltaEngine {
    fun calculate(
        previous: InvestmentBalanceSnapshotEntity?,
        currentCostPaise: Long,
        currentValuePaise: Long
    ): InvestmentDelta {
        require(currentCostPaise >= 0) { "Cost cannot be negative." }
        require(currentValuePaise >= 0) { "Current value cannot be negative." }
        val previousCost = previous?.totalCostPaise
        val previousValue = previous?.currentValuePaise
        val costDelta = currentCostPaise - (previousCost ?: currentCostPaise)
        val valueDelta = currentValuePaise - (previousValue ?: currentValuePaise)
        val contribution = if (previous == null) currentCostPaise else costDelta
        val marketMovement = if (previous == null) currentValuePaise - currentCostPaise else valueDelta - contribution
        return InvestmentDelta(
            previousCostPaise = previousCost,
            previousValuePaise = previousValue,
            costDeltaPaise = if (previous == null) currentCostPaise else costDelta,
            valueDeltaPaise = if (previous == null) currentValuePaise else valueDelta,
            netContributionPaise = contribution,
            marketMovementPaise = marketMovement,
            unrealizedGainPaise = currentValuePaise - currentCostPaise
        )
    }

    fun apply(
        base: InvestmentBalanceSnapshotEntity,
        previous: InvestmentBalanceSnapshotEntity?
    ): InvestmentBalanceSnapshotEntity {
        val delta = calculate(previous, base.totalCostPaise, base.currentValuePaise)
        return base.copy(
            netContributionPaise = delta.netContributionPaise,
            previousCostPaise = delta.previousCostPaise,
            previousValuePaise = delta.previousValuePaise,
            costDeltaPaise = delta.costDeltaPaise,
            valueDeltaPaise = delta.valueDeltaPaise,
            marketMovementPaise = delta.marketMovementPaise
        )
    }
}
