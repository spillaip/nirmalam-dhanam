package com.nirmalamgroup.nirmalamdhanam.domain.usecase

import com.nirmalamgroup.nirmalamdhanam.data.local.AccountEntity
import com.nirmalamgroup.nirmalamdhanam.data.local.InvestmentBalanceSnapshotEntity
import com.nirmalamgroup.nirmalamdhanam.data.local.TransactionDirection
import com.nirmalamgroup.nirmalamdhanam.data.local.EnvelopeType
import com.nirmalamgroup.nirmalamdhanam.data.local.TransactionEntity
import java.time.LocalDate
import java.time.ZoneId

sealed interface FinancialEvent {
    val sortEpochMs: Long
    val title: String
    val detail: String

    data class Transaction(
        val source: TransactionEntity,
        override val title: String,
        override val detail: String
    ) : FinancialEvent { override val sortEpochMs: Long = source.occurredAtEpochMs }

    data class InvestmentCheckIn(
        val source: InvestmentBalanceSnapshotEntity,
        override val title: String,
        override val detail: String
    ) : FinancialEvent {
        override val sortEpochMs: Long = LocalDate.ofEpochDay(source.asOfEpochDay)
            .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }
}

object FinancialTimelineBuilder {
    private fun money(paise: Long): String = "₹%,.2f".format(paise / 100.0)
    fun build(
        transactions: List<TransactionEntity>,
        snapshots: List<InvestmentBalanceSnapshotEntity>,
        accounts: List<AccountEntity>,
        sinceEpochMs: Long? = null
    ): List<FinancialEvent> {
        val accountNames = accounts.associate { it.id to it.name }
        val txEvents = transactions.asSequence()
            .filter { sinceEpochMs == null || it.occurredAtEpochMs >= sinceEpochMs }
            .map { t ->
                val verb = when {
                    t.envelopeType == EnvelopeType.INVESTMENT -> "Investment transfer"
                    t.direction == TransactionDirection.CREDIT -> "Income received"
                    else -> "Expense recorded"
                }
                FinancialEvent.Transaction(
                    source = t,
                    title = verb,
                    detail = listOfNotNull(t.payee, t.category, accountNames[t.accountId]).joinToString(" · ")
                )
            }
        val snapshotEvents = snapshots.asSequence()
            .map { s ->
                val title = when {
                    s.netContributionPaise > 0 -> "Investment contribution + balance update"
                    s.netContributionPaise < 0 -> "Investment withdrawal + balance update"
                    else -> "Investment balance updated"
                }
                val movement = when {
                    s.marketMovementPaise > 0 -> "market movement +${money(s.marketMovementPaise)}"
                    s.marketMovementPaise < 0 -> "market movement ${money(s.marketMovementPaise)}"
                    else -> "no market movement recorded"
                }
                FinancialEvent.InvestmentCheckIn(s, title, "${accountNames[s.accountId] ?: "Investment"} · $movement")
            }
            .filter { sinceEpochMs == null || it.sortEpochMs >= sinceEpochMs }
        return (txEvents + snapshotEvents).sortedByDescending { it.sortEpochMs }.toList()
    }
}
