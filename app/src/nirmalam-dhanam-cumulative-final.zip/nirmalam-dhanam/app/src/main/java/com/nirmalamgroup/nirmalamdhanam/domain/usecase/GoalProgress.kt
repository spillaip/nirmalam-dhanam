package com.nirmalamgroup.nirmalamdhanam.domain.usecase

import com.nirmalamgroup.nirmalamdhanam.data.local.AccountBalance
import com.nirmalamgroup.nirmalamdhanam.data.local.GoalAllocationEntity
import com.nirmalamgroup.nirmalamdhanam.data.local.GoalEntity
import com.nirmalamgroup.nirmalamdhanam.data.local.InvestmentBalanceSnapshotEntity

data class GoalProgress(
    val goal: GoalEntity,
    val fundedPaise: Long,
    val targetPaise: Long,
    val progressPercent: Double
)

object GoalProgressCalculator {
    fun calculate(
        goals: List<GoalEntity>,
        allocations: List<GoalAllocationEntity>,
        balances: List<AccountBalance>,
        latestInvestments: List<InvestmentBalanceSnapshotEntity>
    ): List<GoalProgress> {
        val accountValues = balances.associate { it.accountId to it.balancePaise.coerceAtLeast(0) }.toMutableMap()
        latestInvestments.forEach { accountValues[it.accountId] = it.currentValuePaise.coerceAtLeast(0) }
        val allocationsByGoal = allocations.groupBy { it.goalId }
        return goals.map { goal ->
            val funded = allocationsByGoal[goal.id].orEmpty().sumOf { allocation ->
                val value = accountValues[allocation.accountId] ?: 0L
                value * allocation.allocationBps / 10_000
            }
            GoalProgress(
                goal = goal,
                fundedPaise = funded,
                targetPaise = goal.targetAmountPaise,
                progressPercent = if (goal.targetAmountPaise <= 0) 0.0 else (funded * 100.0 / goal.targetAmountPaise).coerceIn(0.0, 100.0)
            )
        }
    }
}
