buildscript {
    // AGP 9.x has built-in Kotlin. Supplying KGP here selects Kotlin 2.4.20
    // without re-applying the legacy Android Kotlin plugin.
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.20")
    }
}

plugins {
    id("com.android.application") version "9.4.1" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "2.4.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.20" apply false
    id("com.google.devtools.ksp") version "2.3.12" apply false
}


val verifyModernAgpConfiguration by tasks.registering {
    group = "verification"
    description = "Fails if AGP built-in Kotlin/new DSL legacy opt-outs are reintroduced."

    val gradlePropertiesFile = layout.projectDirectory.file("gradle.properties")
    val rootBuildFile = layout.projectDirectory.file("build.gradle.kts")
    val appBuildFile = layout.projectDirectory.file("app/build.gradle.kts")

    inputs.files(gradlePropertiesFile, rootBuildFile, appBuildFile)

    doLast {
        val properties = gradlePropertiesFile.asFile.readText()
        val rootBuild = rootBuildFile.asFile.readText()
        val appBuild = appBuildFile.asFile.readText()

        fun activeProperty(name: String, forbiddenValue: String): Boolean =
            properties.lineSequence()
                .map { it.substringBefore('#').trim() }
                .filter { it.isNotEmpty() }
                .any { line ->
                    val key = line.substringBefore('=').trim()
                    val value = line.substringAfter('=', missingDelimiterValue = "").trim()
                    key == name && value.equals(forbiddenValue, ignoreCase = true)
                }

        check(!activeProperty("android.builtInKotlin", "false")) {
            "AGP built-in Kotlin must remain enabled; remove android.builtInKotlin=false."
        }
        check(!activeProperty("android.newDsl", "false")) {
            "AGP new DSL must remain enabled; remove android.newDsl=false."
        }

        fun activeBuildText(text: String): String =
            text.lineSequence()
                .map { it.substringBefore("//") }
                .joinToString("\n")

        val activeRootBuild = activeBuildText(rootBuild)
        val activeAppBuild = activeBuildText(appBuild)
        val pluginRequests = activeRootBuild + "\n" + activeAppBuild
        val legacyKotlinPluginApplied = listOf(
            "id(\"org.jetbrains.kotlin.android\")",
            "id(\"kotlin-android\")",
            "kotlin(\"android\")",
        ).any { it in pluginRequests }

        check(!legacyKotlinPluginApplied) {
            "Do not re-apply the legacy Kotlin Android plugin with AGP built-in Kotlin."
        }
        check("kotlinOptions" !in activeAppBuild) {
            "Use built-in Kotlin compilerOptions (or inherit compileOptions); android.kotlinOptions is legacy."
        }
        check(
            "applicationVariants" !in activeAppBuild &&
                "libraryVariants" !in activeAppBuild &&
                "variantFilter" !in activeAppBuild
        ) {
            "Legacy AGP variant APIs are not allowed; use the modern Android Components/Variant API."
        }
    }
}

val verifyNoDeadSmsIngestion by tasks.registering {
    group = "verification"
    description = "Prevents dormant SMS receiver/permission code from re-entering the app without a complete feature implementation."

    val manifestFile = layout.projectDirectory.file("app/src/main/AndroidManifest.xml")
    val mainSourceDir = layout.projectDirectory.dir("app/src/main/java")

    inputs.file(manifestFile)
    inputs.dir(mainSourceDir)

    doLast {
        val forbiddenManifestTokens = listOf(
            "android.permission.RECEIVE_SMS",
            "android.permission.READ_SMS",
            "android.provider.Telephony.SMS_RECEIVED",
            "SmsBroadcastReceiver",
        )
        val manifest = manifestFile.asFile.readText()
        forbiddenManifestTokens.forEach { token ->
            check(token !in manifest) {
                "Dormant SMS ingestion is not allowed: AndroidManifest.xml contains $token. " +
                    "Only reintroduce SMS access together with a complete, user-visible, policy-reviewed ingestion feature."
            }
        }

        val forbiddenSourceTokens = listOf(
            "SmsBroadcastReceiver",
            "SmsIngestionDispatcher",
            "Telephony.Sms",
            "Telephony.SMS_RECEIVED",
        )
        mainSourceDir.asFile.walkTopDown()
            .filter { it.isFile && it.extension in setOf("kt", "java") }
            .forEach { source ->
                val text = source.readText()
                forbiddenSourceTokens.forEach { token ->
                    check(token !in text) {
                        "Dormant SMS ingestion is not allowed: ${source.relativeTo(rootDir)} contains $token. " +
                            "Either remove the dead path or implement the complete feature before restoring it."
                    }
                }
            }
    }
}


val verifyNoPackagedStoreArtwork by tasks.registering {
    group = "verification"
    description = "Keeps Play Store listing artwork out of runtime resources and requires adaptive launcher icons."

    val resDir = layout.projectDirectory.dir("app/src/main/res")
    val storeAssetsDir = layout.projectDirectory.dir("store-assets")

    inputs.dir(resDir)
    inputs.dir(storeAssetsDir)

    doLast {
        val resRoot = resDir.asFile
        val forbiddenNameTokens = listOf(
            "feature_graphic",
            "play_store",
            "playstore",
            "store_icon",
        )

        resRoot.walkTopDown()
            .filter { it.isFile }
            .forEach { file ->
                val lowerName = file.name.lowercase()
                check(forbiddenNameTokens.none { it in lowerName }) {
                    "Play Store listing artwork must stay outside app/src/main/res: ${file.relativeTo(rootDir)}"
                }
                val parent = file.parentFile?.name.orEmpty()
                check(!(parent.startsWith("mipmap-") && file.name in setOf("ic_launcher.png", "ic_launcher_round.png"))) {
                    "Launcher icons must remain adaptive XML resources; remove legacy bitmap ${file.relativeTo(rootDir)}"
                }
            }

        val adaptiveV26 = listOf(
            resRoot.resolve("mipmap-anydpi-v26/ic_launcher.xml"),
            resRoot.resolve("mipmap-anydpi-v26/ic_launcher_round.xml"),
        )
        adaptiveV26.forEach { file ->
            check(file.isFile && "<adaptive-icon" in file.readText()) {
                "Missing adaptive launcher icon resource: ${file.relativeTo(rootDir)}"
            }
        }

        val themedV33 = listOf(
            resRoot.resolve("mipmap-anydpi-v33/ic_launcher.xml"),
            resRoot.resolve("mipmap-anydpi-v33/ic_launcher_round.xml"),
        )
        themedV33.forEach { file ->
            val xml = file.takeIf { it.isFile }?.readText().orEmpty()
            check("<adaptive-icon" in xml && "<monochrome" in xml) {
                "Android 13+ launcher resource must keep its monochrome themed-icon layer: ${file.relativeTo(rootDir)}"
            }
        }

        check(storeAssetsDir.asFile.resolve("nirmalam_play_store_icon_512.png").isFile) {
            "Play Store icon source belongs in store-assets/, not app resources."
        }
        check(storeAssetsDir.asFile.resolve("nirmalam_feature_graphic_1024x500.png").isFile) {
            "Play Store feature graphic belongs in store-assets/, not app resources."
        }
    }
}

val verifySourceArchitecture by tasks.registering {
    group = "verification"
    description = "Keeps MainActivity thin and prevents UI/database orchestration from collapsing back into it."

    val sourceDir = layout.projectDirectory.dir("app/src/main/java/com/nirmalamgroup/nirmalamdhanam")
    val mainActivityFile = sourceDir.file("MainActivity.kt")
    val viewModelFile = sourceDir.file("NirmalamMvpViewModel.kt")
    val homeFile = sourceDir.file("HomeScreen.kt")

    inputs.files(mainActivityFile, viewModelFile, homeFile)

    doLast {
        val main = mainActivityFile.asFile.readText()
        val mainLines = main.lineSequence().count()
        check(mainLines <= 60) { "MainActivity.kt must remain a thin launcher (<= 60 lines); found $mainLines." }
        listOf("AndroidViewModel", "NirmalamDatabase", "@Composable", "withTransaction").forEach { forbidden ->
            check(forbidden !in main) { "MainActivity.kt must not own UI/business/persistence orchestration: found $forbidden." }
        }
        check(viewModelFile.asFile.exists()) { "Finance ViewModel must remain outside MainActivity.kt." }
        check(homeFile.asFile.exists()) { "Home/navigation UI must remain outside MainActivity.kt." }
    }
}

val verifyCumulativeIntegrity by tasks.registering {
    group = "verification"
    description = "Guards the cumulative finance/data fixes against accidental regression."

    val databaseFile = layout.projectDirectory.file("app/src/main/java/com/nirmalamgroup/nirmalamdhanam/data/local/NirmalamDatabase.kt")
    val daoFile = layout.projectDirectory.file("app/src/main/java/com/nirmalamgroup/nirmalamdhanam/data/local/Daos.kt")
    val backupFile = layout.projectDirectory.file("app/src/main/java/com/nirmalamgroup/nirmalamdhanam/data/local/NdfBackupManager.kt")
    val csvFile = layout.projectDirectory.file("app/src/main/java/com/nirmalamgroup/nirmalamdhanam/data/local/CsvTransactionExporter.kt")
    val csvCodecFile = layout.projectDirectory.file("app/src/main/java/com/nirmalamgroup/nirmalamdhanam/data/local/CsvCodec.kt")
    val viewModelFile = layout.projectDirectory.file("app/src/main/java/com/nirmalamgroup/nirmalamdhanam/NirmalamMvpViewModel.kt")
    val coolingFile = layout.projectDirectory.file("app/src/main/java/com/nirmalamgroup/nirmalamdhanam/domain/usecase/FinanceUseCases.kt")
    val rolePolicyFile = layout.projectDirectory.file("app/src/main/java/com/nirmalamgroup/nirmalamdhanam/domain/usecase/AccountRolePolicy.kt")
    val appBuildFile = layout.projectDirectory.file("app/build.gradle.kts")

    inputs.files(databaseFile, daoFile, backupFile, csvFile, csvCodecFile, viewModelFile, coolingFile, rolePolicyFile, appBuildFile)

    doLast {
        val database = databaseFile.asFile.readText()
        val dao = daoFile.asFile.readText()
        val backup = backupFile.asFile.readText()
        val csv = csvFile.asFile.readText()
        val csvCodec = csvCodecFile.asFile.readText()
        val viewModel = viewModelFile.asFile.readText()
        val cooling = coolingFile.asFile.readText()
        val rolePolicy = rolePolicyFile.asFile.readText()
        val appBuild = appBuildFile.asFile.readText()

        check("const val SCHEMA_VERSION = 14" in database && "MIGRATION_12_13" in database && "MIGRATION_13_14" in database) {
            "Room schema/migration repair regressed; keep the cumulative v12->v13->v14 chain intact."
        }
        check("SupportSQLiteOpenHelper.Callback(expectedSchemaVersion)" in backup && "Callback(2)" !in backup) {
            "NDF validation must follow the expected/current Room schema version; do not hard-code Callback(2)."
        }
        check("WHERE isHoldingTank = 1 ORDER BY" in dao && "coolDownExpiryEpochMs <= :nowEpochMs" in dao) {
            "Cooling-tank rows must remain visible after expiry and confirmation must enforce the expiry boundary."
        }
        check("observeAll()" in viewModel && "allTransactions = day.all" in viewModel) {
            "Reports/AI must retain a full-ledger state separate from the capped recent feed."
        }
        check("LocalDayClock.window" in viewModel && "86_400_000" !in viewModel && "86400000" !in viewModel) {
            "Today must use local calendar boundaries, not UTC epoch-day arithmetic."
        }
        check("CsvCodec.parse" in csv && "database.withTransaction" in csv && "parseCsvLine" !in csv && "object CsvCodec" in csvCodec) {
            "CSV import/export must keep the strict codec and atomic Room transaction path."
        }
        val activeCooling = cooling
            .replace(Regex("/\\*.*?\\*/", setOf(RegexOption.DOT_MATCHES_ALL)), "")
            .lineSequence()
            .map { it.substringBefore("//") }
            .joinToString("\n")
        check("categoryPriority == CategoryPriority.WANT" in activeCooling && "\"Shopping\"" !in activeCooling) {
            "Cooling policy must be driven by CategoryPriority.WANT, never a category label."
        }
        check("transactionAccountKinds" in rolePolicy && "AccountKind.SAVINGS" in rolePolicy && "AccountKind.EMERGENCY" in rolePolicy) {
            "Savings/Emergency roles must stay usable by ledger operations."
        }
        check("BuildConfig.DEBUG" in viewModel && "seedDemoDataIfEmpty" in viewModel) {
            "Synthetic demo financial data must remain debug-only."
        }
        listOf("2024.09", "activity-compose:1.9.2", "lifecycle-runtime-ktx:2.8.6", "core-ktx:1.13.1", "kotlin-test-junit:2.2.10").forEach { stale ->
            check(stale !in appBuild) { "Stale dependency reintroduced: $stale" }
        }
    }
}
